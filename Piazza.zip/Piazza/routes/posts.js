const express = require('express')
const router = express.Router()

const Post = require('../models/Post')
const verifyToken = require('../verifyToken')
const {postValidation} = require('../validations/validation')


//get posts accessible to public
router.get('/', async(req,res) =>{
    try{

        const posts = await Post.find()
        res.send(posts)
    }catch(err){
        res.status(400).send({message:err})
    }
})

//make a post must have verified token
//POST (Create Data)
router.post('/', verifyToken, async(req,res)=>{
    //console.log(req.body)
    //validation to check user
    const {error} = postValidation(req.body)
    if(error){
        return res.status(400).send({message:error['details'][0]['message']})
    }

    const postData = new Post({
        title:req.body.title,
        description:req.body.description,
        createdBy:req.user._id
    })
    //try to insert...
    try{
        const postToSave = await postData.save()
        res.send(postToSave)
    }catch(err){
        res.status(400).send({message:err})
    }
})

//GET 1(Read all)
router.get('/', async(req,res)=>{
    try{
        const getPosts = await Post.find().limit(10)
        res.send(getPosts) 
    }catch(err){
        res.status(400).send({message:err})
    }
})

//GET 2 (Read by Id)
router.get('/:postId', async(req,res)=>{
    try{
        const getPostById = await Post.findById(req.params.postId)
        res.send(getPostById) 
    }catch(err){
        res.status(400).send({message:err})
    }
})

//PATCH (Update)
router.patch('/:postId', verifyToken, async(req,res)=>{
    try{
        //validation to check user
        const {error} = postValidation(req.body)
        if(error){
            return res.status(400).send({message:error['details'][0]['message']})
        }

        const getPostById = await Post.findById(req.params.postId)
        
        if(getPostById.createdBy != req.user._id){
            return res.status(401).send({message:'This is not your post bro'})
        }
        const updatePostById = await Post.updateOne(
            {_id:req.params.postId}, //first step: match your id in the database with the id of the user
            //second step: set the data to the new post data
            {$set:{
                title:req.body.title,
                description:req.body.description,
                }
            })
        return res.send(updatePostById)
    }catch(err){
        return res.status(400).send({message:err})
    }
})

//DELETE (delete)
router.delete('/:postId', verifyToken, async(req,res)=>{
    try{
        const getPostById = await Post.findById(req.params.postId)
        if(getPostById.createdBy != req.user._id){
            return res.status(401).send({message:'This is not your post bro'})
        }

        const deletePostById = await Post.deleteOne({_id:req.params.postId})
        return res.send(deletePostById)
    }catch(err){
        return res.status(400).send({message:err})
    }
})

module.exports = router